import type { MedusaRequest, MedusaResponse } from "@medusajs/framework/http"
import { GIFT_CARD_LEDGER_MODULE } from "../../../../modules/gift-card-ledger"

export const GET = async (req: MedusaRequest, res: MedusaResponse) => {
  const { code } = req.params
  const svc = req.scope.resolve(GIFT_CARD_LEDGER_MODULE)

  const { card, balance } = await svc.getByCode(code)
  res.json({
    code: card.code,
    currency: card.currency,
    status: card.status,
    legal_entity_id: card.legal_entity_id,
    balance,
  })
}

export const POST = async (req: MedusaRequest, res: MedusaResponse) => {
  // redeem endpoint: POST /store/gift-cards/:code
  const { code } = req.params
  const { amount, currency, reference, idempotency_key } = req.body as {
    amount: number
    currency: string
    reference: string
    idempotency_key: string
  }

  const svc = req.scope.resolve(GIFT_CARD_LEDGER_MODULE)
  const out = await svc.redeem({
    code,
    amount,
    currency,
    reference,
    source: "MEDUSA",
    idempotency_key,
  })

  res.json(out)
}