import type { MedusaRequest, MedusaResponse } from "@medusajs/framework/http"
//import { GIFT_CARD_LEDGER_MODULE } from "../../../../../modules/gift-card-ledger"

export const POST = async (req: MedusaRequest, res: MedusaResponse) => {
  // TODO: enforce POS auth (API key/JWT), rate limit
  const { code, amount, currency, pos_receipt_id, idempotency_key } = req.body as {
    code: string
    amount: number
    currency: string
    pos_receipt_id: string
    idempotency_key: string
  }

  const svc = req.scope.resolve(GIFT_CARD_LEDGER_MODULE)
  const out = await svc.redeem({
    code,
    amount,
    currency,
    reference: pos_receipt_id,
    source: "LIGHTSPEED",
    idempotency_key,
  })

  res.json(out)
}