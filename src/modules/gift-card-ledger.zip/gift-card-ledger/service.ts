import { MedusaService } from "@medusajs/framework/utils"
import type { EntityManager } from "@mikro-orm/postgresql"
import { GiftCard, GiftCardStatus } from "./models/gift-card"
import { GiftCardEvent } from "./models/gift-card-event"
import { randomBytes } from "crypto"

type IssueInput = {
  amount: number // cents
  currency: string
  legal_entity_id: string
  reference: string
  source?: "MEDUSA" | "ADMIN"
  idempotency_key: string
}

type RedeemInput = {
  code: string
  amount: number // cents, positive input
  currency: string
  reference: string
  source: "MEDUSA" | "LIGHTSPEED"
  idempotency_key: string
}

export class GiftCardLedgerService extends MedusaService({
  GiftCard,
  GiftCardEvent,
}) {
  // MedusaService gives you a scoped manager at runtime (MikroORM EntityManager)
  protected getManager(): EntityManager {
    // @ts-expect-error medusa runtime injects this
    return this.container.resolve("manager")
  }

  private generateCode(): string {
    // 128-bit entropy ~ 22 chars base64url-ish; keep it simple & long
    return "GC-" + randomBytes(16).toString("hex").toUpperCase()
  }

  async issue(input: IssueInput) {
    if (input.amount <= 0) throw new Error("amount must be > 0")

    const em = this.getManager()

    return await em.transactional(async (tx) => {
      // Idempotency: if event exists, return derived state
      const existing = await tx.findOne(GiftCardEvent, { idempotency_key: input.idempotency_key }, { populate: ["gift_card"] })
      if (existing) {
        const balance = await this.getBalanceByGiftCardId(tx, existing.gift_card.id)
        return { code: existing.gift_card.code, balance, event_id: existing.id }
      }

      const card = new GiftCard()
      card.code = this.generateCode()
      card.currency = input.currency
      card.legal_entity_id = input.legal_entity_id
      card.status = GiftCardStatus.ACTIVE

      const ev = new GiftCardEvent()
      ev.gift_card = card
      ev.type = "ISSUE"
      ev.amount = input.amount
      ev.currency = input.currency
      ev.source = input.source ?? "MEDUSA"
      ev.reference = input.reference
      ev.idempotency_key = input.idempotency_key

      tx.persist(card)
      tx.persist(ev)
      await tx.flush()

      return { code: card.code, balance: input.amount, event_id: ev.id }
    })
  }

  async getByCode(code: string) {
    const em = this.getManager()
    const card = await em.findOne(GiftCard, { code })
    if (!card) throw new Error("gift card not found")
    const balance = await this.getBalanceByGiftCardId(em, card.id)
    return { card, balance }
  }

  async redeem(input: RedeemInput) {
    if (input.amount <= 0) throw new Error("amount must be > 0")

    const em = this.getManager()

    return await em.transactional(async (tx) => {
      // Idempotency first
      const existing = await tx.findOne(GiftCardEvent, { idempotency_key: input.idempotency_key }, { populate: ["gift_card"] })
      if (existing) {
        const balance = await this.getBalanceByGiftCardId(tx, existing.gift_card.id)
        return { approved_amount: Math.abs(existing.amount), remaining_balance: balance, event_id: existing.id }
      }

      // Atomicity: lock the gift card row. MikroORM supports pessimistic lock.
      const card = await tx.findOne(GiftCard, { code: input.code }, { lockMode: 2 /* PESSIMISTIC_WRITE */ })
      if (!card) throw new Error("gift card not found")
      if (card.status !== GiftCardStatus.ACTIVE) throw new Error("gift card disabled")
      if (card.currency !== input.currency) throw new Error("currency mismatch")

      const balance = await this.getBalanceByGiftCardId(tx, card.id)
      const approved = Math.min(balance, input.amount)

      if (approved <= 0) {
        return { approved_amount: 0, remaining_balance: balance, event_id: null }
      }

      const ev = new GiftCardEvent()
      ev.gift_card = card
      ev.type = "REDEEM"
      ev.amount = -approved
      ev.currency = input.currency
      ev.source = input.source
      ev.reference = input.reference
      ev.idempotency_key = input.idempotency_key

      tx.persist(ev)
      await tx.flush()

      const remaining = balance - approved
      return { approved_amount: approved, remaining_balance: remaining, event_id: ev.id }
    })
  }

  async listEvents(code: string) {
    const em = this.getManager()
    const card = await em.findOne(GiftCard, { code })
    if (!card) throw new Error("gift card not found")
    return await em.find(GiftCardEvent, { gift_card: card }, { orderBy: { occurred_at: "DESC" as any } })
  }

  private async getBalanceByGiftCardId(em: EntityManager, giftCardId: string): Promise<number> {
    const res = await em
      .createQueryBuilder(GiftCardEvent)
      .select("COALESCE(SUM(amount), 0) as balance")
      .where({ gift_card: giftCardId as any })
      .execute()

    return Number(res?.[0]?.balance ?? 0)
  }
}