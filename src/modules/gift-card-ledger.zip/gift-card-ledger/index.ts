import { Module } from "@medusajs/framework/utils"
import { GiftCardLedgerService } from "./service"
import { GiftCard } from "./models/gift-card"
import { GiftCardEvent } from "./models/gift-card-event"

export const GIFT_CARD_LEDGER_MODULE = "giftCardLedger"

export default Module(GIFT_CARD_LEDGER_MODULE, {
  service: GiftCardLedgerService,
  entities: [GiftCard, GiftCardEvent],
})