import { Entity, PrimaryKey, Property, ManyToOne, Index, Unique } from "@mikro-orm/core"
import { randomUUID } from "crypto"
import { GiftCard } from "./gift-card"

export type GiftCardEventType = "ISSUE" | "REDEEM" | "VOID"
export type GiftCardEventSource = "MEDUSA" | "LIGHTSPEED" | "ADMIN"

@Entity({ tableName: "gift_card_event" })
@Unique({ properties: ["idempotency_key"] })
export class GiftCardEvent {
  @PrimaryKey({ type: "uuid" })
  id: string = randomUUID()

  @ManyToOne(() => GiftCard, { fieldName: "gift_card_id" })
  gift_card!: GiftCard

  @Property()
  type!: GiftCardEventType

  // signed integer cents: ISSUE positive, REDEEM negative
  @Property()
  amount!: number

  @Property()
  currency!: string

  @Property()
  source!: GiftCardEventSource

  @Property()
  reference!: string // order_id or pos_receipt_id

  @Index()
  @Property()
  idempotency_key!: string

  @Property({ onCreate: () => new Date() })
  occurred_at: Date = new Date()
}