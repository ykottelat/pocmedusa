import { Entity, PrimaryKey, Property, Unique, Enum } from "@mikro-orm/core"
import { randomUUID } from "crypto"

export enum GiftCardStatus {
  ACTIVE = "active",
  DISABLED = "disabled",
}

@Entity({ tableName: "gift_card" })
export class GiftCard {
  @PrimaryKey({ type: "uuid" })
  id: string = randomUUID()

  @Property()
  @Unique()
  code!: string

  @Property()
  currency!: string // e.g. "CHF"

  @Property()
  legal_entity_id!: string

  @Enum(() => GiftCardStatus)
  status: GiftCardStatus = GiftCardStatus.ACTIVE

  @Property({ onCreate: () => new Date() })
  created_at: Date = new Date()
}